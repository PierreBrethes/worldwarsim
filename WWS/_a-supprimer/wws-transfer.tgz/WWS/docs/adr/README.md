# Décisions d'architecture (ADR)

Une ADR grave **pourquoi** une décision a été prise, pas seulement laquelle. C'est ce qui empêche de
refaire trois fois le même débat, et ce qui permet de revenir sur un choix en connaissance de cause
quand le contexte change.

Format : Contexte → Décision → Conséquences → Ce qu'on abandonne.

| # | Décision | Statut |
|---|---|---|
| [0001](0001-saison-longue-asynchrone.md) | Saison longue asynchrone plutôt que parties de 30 min | acceptée |
| [0002](0002-plan-incline-plutot-que-globe.md) | Plan incliné à faux horizon plutôt que globe | acceptée |
| [0003](0003-courbure-cpu.md) | Courbure appliquée CPU et non dans le vertex shader | acceptée |
| [0004](0004-avant-postes-plutot-que-conquete.md) | Avant-postes ponctuels plutôt que conquête de provinces | acceptée |
| [0005](0005-brouillard-par-defaut.md) | Brouillard de guerre par défaut | acceptée |
| [0006](0006-slots-de-mouvement.md) | Slots de mouvement comme régulateur central | acceptée |
| [0007](0007-epoque-1940.md) | Époque 1940 plutôt que matériel moderne | acceptée |
| [0008](0008-combat-par-interception.md) | Combat par interception et rejeu, pas de tour par tour | acceptée |
