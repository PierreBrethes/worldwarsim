import { useSyncExternalStore } from 'react';

const ACTIVE_KEY = 'wws-token';
const LIST_KEY = 'wws-tokens';

const subscribers = new Set<() => void>();

const announce = (): void => {
  for (const subscriber of subscribers) subscriber();
};

export const readToken = (): string | null => localStorage.getItem(ACTIVE_KEY);

const EMPTY: ReadonlyArray<string> = [];

let snapshot: { readonly signature: string; readonly tokens: ReadonlyArray<string> } | null = null;

/**
 * **Every game this browser holds a seat in**, active one included. A player accumulates
 * seasons — one in a lobby, one running, one already won — and the home screen lists them all.
 *
 * The active token is folded in at read time rather than migrated by a write: an older client
 * has a `wws-token` and no list, and deriving the union costs nothing, runs on every read, and
 * needs no "have I migrated yet" flag. The first `keepToken` persists the union anyway.
 *
 * The result is memoised on the raw storage strings because `useSyncExternalStore` compares
 * snapshots by identity: a fresh array on every read is an infinite render loop.
 */
export function readTokens(): ReadonlyArray<string> {
  const stored = localStorage.getItem(LIST_KEY);
  const active = localStorage.getItem(ACTIVE_KEY);
  const signature = `${stored ?? ''}\u0000${active ?? ''}`;
  if (snapshot?.signature === signature) return snapshot.tokens;
  const kept = parseList(stored);
  const tokens = active === null || kept.includes(active) ? kept : [...kept, active];
  snapshot = { signature, tokens };
  return tokens;
}

export const keepToken = (token: string): void => {
  const kept = readTokens();
  localStorage.setItem(LIST_KEY, JSON.stringify(kept.includes(token) ? kept : [...kept, token]));
  localStorage.setItem(ACTIVE_KEY, token);
  announce();
};

/**
 * Drops one seat. The active token is cleared only when it is the one being dropped: quitting
 * a lobby must not blank out the game the player was reading in another tab.
 */
export const forgetToken = (token: string): void => {
  localStorage.setItem(LIST_KEY, JSON.stringify(readTokens().filter((kept) => kept !== token)));
  if (localStorage.getItem(ACTIVE_KEY) === token) localStorage.removeItem(ACTIVE_KEY);
  announce();
};

/**
 * The token as a reactive source. Reading `readToken()` straight from a render body worked
 * by accident: the value only changed on a navigation that remounted the component anyway.
 * It stopped being true across tabs — quitting a lobby in one leaves the other showing a
 * game it no longer holds a token for.
 *
 * `storage` only fires in the *other* tabs, never the one that wrote, hence the manual
 * announce in `keepToken` and `forgetToken`.
 */
export function useToken(): string | null {
  return useSyncExternalStore(subscribe, readToken, () => null);
}

/** The same source, read as a list — the home screen's "mes parties". */
export function useTokens(): ReadonlyArray<string> {
  return useSyncExternalStore(subscribe, readTokens, () => EMPTY);
}

function parseList(stored: string | null): ReadonlyArray<string> {
  if (stored === null) return EMPTY;
  try {
    const parsed: unknown = JSON.parse(stored);
    if (!Array.isArray(parsed)) return EMPTY;
    return parsed.filter((entry): entry is string => typeof entry === 'string');
  } catch {
    return EMPTY;
  }
}

function subscribe(listener: () => void): () => void {
  subscribers.add(listener);
  if (subscribers.size === 1) window.addEventListener('storage', onStorage);
  return () => {
    subscribers.delete(listener);
    if (subscribers.size === 0) window.removeEventListener('storage', onStorage);
  };
}

function onStorage(event: StorageEvent): void {
  // A `null` key means the whole store was cleared, which concerns us too.
  if (event.key === ACTIVE_KEY || event.key === LIST_KEY || event.key === null) announce();
}
