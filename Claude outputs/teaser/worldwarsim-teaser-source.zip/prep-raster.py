"""Champ de distance à la côte et isobathes, en unités de carte (400 × 208).

Le jeu n'a pas de bathymétrie : la distance au rivage en tient lieu, comme le lavis côtier
du moteur (`coastal-wash.ts`). Les courbes servent deux fois : en isobathes à l'encre sur le
plateau, et en bandes de trame (similigravure) sur la planche imprimée.
"""
import json
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage
from skimage import measure

S = 12          # pixels par unité de carte
PAD = 4         # unités de mer ajoutées autour, pour que toutes les courbes se ferment
W, H = 400, 208
LEVELS = [0.35, 0.8, 1.4, 2.3]

geo = json.load(open('data/geo.json'))
w, h = (W + 2 * PAD) * S, (H + 2 * PAD) * S
img = Image.new('L', (w, h), 0)
draw = ImageDraw.Draw(img)
for country in geo['countries']:
    for ring in country['p']:
        pts = [((x + PAD) * S, (y + PAD) * S) for x, y in ring]
        if len(pts) >= 3:
            draw.polygon(pts, fill=255)
land = np.array(img) > 127
dist = ndimage.distance_transform_edt(~land) / S   # unités de carte, 0 sur terre
print('raster', land.shape, 'terre', round(land.mean() * 100, 1), '%')

out = {'levels': LEVELS, 'lines': {}}
for level in LEVELS:
    lines = []
    for contour in measure.find_contours(dist, level):
        simple = measure.approximate_polygon(contour, tolerance=0.55)
        if len(simple) < 4:
            continue
        pts = [[round(c / S - PAD, 3), round(r / S - PAD, 3)] for r, c in simple]
        # Les anneaux minuscules (rochers) ne disent rien à cette échelle.
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        if (max(xs) - min(xs)) * (max(ys) - min(ys)) < 0.04:
            continue
        lines.append(pts)
    out['lines'][str(level)] = lines
    print('niveau', level, len(lines), 'courbes,', sum(len(l) for l in lines), 'points')

json.dump(out, open('data/contours.json', 'w'))

# Aperçu de contrôle, une image et rien d'autre.
prev = np.zeros(dist.shape, np.uint8)
prev[land] = 200
for i, level in enumerate(LEVELS):
    band = (dist > 0) & (np.abs(dist - level) < 0.05)
    prev[band] = 60 + 30 * i
Image.fromarray(prev).resize((w // 4, h // 4)).save('out/check-contours.png')
