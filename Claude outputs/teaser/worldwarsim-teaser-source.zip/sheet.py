"""Planche de contrôle : les images fixes côte à côte, réduites, légendées de leur temps."""
import sys
from PIL import Image, ImageDraw

paths = sys.argv[2:]
out = sys.argv[1]
cols = 2 if len(paths) <= 4 else 3
w, h = 960, 540
rows = (len(paths) + cols - 1) // cols
sheet = Image.new('RGB', (cols * w, rows * h), (20, 20, 20))
d = ImageDraw.Draw(sheet)
for i, p in enumerate(paths):
    im = Image.open(p).convert('RGB').resize((w, h), Image.LANCZOS)
    x, y = (i % cols) * w, (i // cols) * h
    sheet.paste(im, (x, y))
    d.rectangle([x, y, x + 120, y + 26], fill=(0, 0, 0))
    d.text((x + 6, y + 6), p.split('still-')[-1].replace('.png', ' s'), fill=(255, 255, 0))
sheet.save(out)
