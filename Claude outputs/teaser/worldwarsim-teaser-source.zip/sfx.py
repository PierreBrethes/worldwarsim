"""Bande son synthétisée — aucun fichier, aucune musique, aucun droit.

Calée sur les temps forts de teaser.js (data/timeline.json, écrit par render.mjs).
Le tic-tac est celui du télégraphe du jeu (src/data/telegraph.ts) : un bruit blanc étouffé en
3,5 ms, passé au passe-bande — 2 400 Hz, puis 1 700 Hz 85 ms plus tard, plus bas et plus court.
Le relevé passe en morse : R-E-L-E-V-E, sur le sondeur, juste avant la passe de résolution.
"""
import json
import numpy as np
from scipy.io import wavfile
from scipy.signal import lfilter

SR = 48000
DUR = 15.0
N = int(SR * DUR)
rng = np.random.default_rng(1940)
T = json.load(open('data/timeline.json'))
mix = np.zeros((N, 2))


def bandpass(x, f, q):
    w0 = 2 * np.pi * f / SR
    alpha = np.sin(w0) / (2 * q)
    b = [alpha, 0, -alpha]
    a = [1 + alpha, -2 * np.cos(w0), 1 - alpha]
    return lfilter(b, a, x)


def lowpass(x, f):
    k = np.exp(-2 * np.pi * f / SR)
    return lfilter([1 - k], [1, -k], x)


def highpass(x, f):
    return x - lowpass(x, f)


def put(sig, t, gain=1.0, pan=0.0):
    """Pose un signal mono à l'instant t, panoramique de −1 (gauche) à 1 (droite)."""
    i = int(t * SR)
    if i >= N:
        return
    sig = sig[: N - i]
    left = np.cos((pan + 1) * np.pi / 4)
    right = np.sin((pan + 1) * np.pi / 4)
    mix[i : i + len(sig), 0] += sig * gain * left * np.sqrt(2)
    mix[i : i + len(sig), 1] += sig * gain * right * np.sqrt(2)


def env_exp(n, tau):
    return np.exp(-np.arange(n) / (SR * tau))


def click(hertz, level, q=1.6, decay=0.0035, length=0.02):
    n = int(SR * length)
    wave = rng.uniform(-1, 1, n) * env_exp(n, decay)
    return bandpass(wave, hertz, q) * level


def tictac(t, gain=5.5, pan=0.0):
    put(click(2400, 0.09), t, gain, pan)
    put(click(1700, 0.06), t + 0.085, gain, pan)


def stamp(t, gain=1.0, pan=0.0):
    """Le tampon : un corps sourd qui tombe en fréquence, la claque, et le papier."""
    n = int(SR * 0.5)
    tt = np.arange(n) / SR
    freq = 55 + 85 * np.exp(-tt / 0.02)
    body = np.sin(2 * np.pi * np.cumsum(freq) / SR) * env_exp(n, 0.085) * np.minimum(1, tt / 0.002)
    slap = bandpass(rng.uniform(-1, 1, n) * env_exp(n, 0.012), 900, 0.8)
    paper = bandpass(rng.uniform(-1, 1, n) * env_exp(n, 0.03), 4500, 0.7)
    put(0.55 * body + 0.9 * slap + 0.35 * paper, t, gain, pan)


def press(t0, dur, gain=1.0, pitch=1.0, bed=0.4):
    """La rotative : un claquement de départ, puis le rouleau qui roule."""
    if gain > 0:
        stamp(t0, 0.45 * gain)
    n = int(SR * 0.4)
    clank = np.zeros(n)
    for f, tau in ((1180, 0.09), (1730, 0.06), (2410, 0.05), (3150, 0.04)):
        clank += np.sin(2 * np.pi * f * pitch * np.arange(n) / SR + rng.uniform(0, 6.28)) * env_exp(n, tau)
    put(clank * 0.05, t0, gain)
    roll = gain if gain > 0 else bed
    n = int(SR * (dur + 0.35))
    tt = np.arange(n) / SR
    shape = np.minimum(1, tt / 0.08) * np.clip((dur + 0.35 - tt) / 0.3, 0, 1)
    pulse = 0.55 + 0.45 * (0.5 + 0.5 * np.sin(2 * np.pi * 7.5 * pitch * tt)) ** 3
    for ch, pan in ((0, -0.5), (1, 0.5)):
        brown = lowpass(np.cumsum(rng.uniform(-1, 1, n)) * 0.02, 220)
        brown -= lowpass(brown, 25)
        rumble = brown / (np.max(np.abs(brown)) + 1e-9)
        hiss = bandpass(rng.uniform(-1, 1, n), 4200, 0.6)
        put((0.32 * rumble * pulse + 0.035 * hiss * pulse) * shape, t0, roll, pan)


def whoosh(t0, dur, gain=1.0, low=280, high=1700):
    n = int(SR * dur)
    u = np.arange(n) / n
    cutoff = low + (high - low) * np.sin(np.pi * u) ** 1.5
    noise = rng.uniform(-1, 1, n)
    out = np.zeros(n)
    y = 0.0
    for i in range(n):  # passe-bas à coefficient glissant
        k = np.exp(-2 * np.pi * cutoff[i] / SR)
        y = (1 - k) * noise[i] + k * y
        out[i] = y
    out = highpass(out, 120)
    put(out * np.sin(np.pi * u) ** 2 * 0.5, t0, gain)


def thump(t, f=50, tau=0.25, gain=1.0):
    n = int(SR * tau * 5)
    tt = np.arange(n) / SR
    put(np.sin(2 * np.pi * f * tt) * env_exp(n, tau) * np.minimum(1, tt / 0.004), t, gain)


def tap(t, gain=1.0, pan=0.0):
    """Un mât qu'on plante : un tic de bois, plus grave que le télégraphe."""
    put(click(900, 0.4, q=2.2, decay=0.006, length=0.05), t, gain, pan)
    n = int(SR * 0.12)
    put(np.sin(2 * np.pi * 180 * np.arange(n) / SR) * env_exp(n, 0.03) * 0.25, t, gain, pan)


def boom(t):
    """La passe de résolution : un coup sourd et lointain, pas une explosion de cinéma."""
    n = int(SR * 2.4)
    tt = np.arange(n) / SR
    drop = 1 + 0.25 * np.exp(-tt / 0.08)
    sub = (0.62 * np.sin(2 * np.pi * np.cumsum(48 * drop) / SR) + 0.3 * np.sin(2 * np.pi * np.cumsum(72 * drop) / SR))
    sub *= env_exp(n, 0.45) * np.minimum(1, tt / 0.005)
    crack = lowpass(rng.uniform(-1, 1, n), 2500) * env_exp(n, 0.06)
    brown = lowpass(np.cumsum(rng.uniform(-1, 1, n)) * 0.02, 150)
    brown -= lowpass(brown, 20)
    tail = brown / (np.max(np.abs(brown)) + 1e-9) * env_exp(n, 0.9)
    put(1.0 * sub + 0.5 * crack + 0.28 * tail, t, 1.0)


def paper_slide(t0, dur, gain=1.0):
    n = int(SR * dur)
    u = np.arange(n) / n
    noise = rng.uniform(-1, 1, n)
    a = bandpass(noise, 2600, 0.8) * (1 - u) + bandpass(noise, 1100, 0.8) * u
    put(a * np.sin(np.pi * np.minimum(1, u * 1.4)) ** 2 * 0.35, t0, gain, pan=0.4)


def morse(t0, word, unit, gain=1.0):
    """Le sondeur : un claquement à l'abaissement, un autre au relâché."""
    code = {'R': '.-.', 'E': '.', 'L': '.-..', 'V': '...-'}
    t = t0
    for letter in word:
        for mark in code[letter]:
            length = unit if mark == '.' else 3 * unit
            put(click(1900, 0.5, q=3.0, decay=0.004), t, gain, 0.25)
            put(click(1250, 0.35, q=2.5, decay=0.005), t + length, gain, 0.25)
            t += length + unit
        t += 2 * unit
    return t


# ---- l'ambiance : le bruit d'une salle, puis le poids du plateau
n = N
room = lowpass(rng.uniform(-1, 1, n), 3000)
room = room / np.max(np.abs(room))
tt = np.arange(n) / SR
room_env = np.minimum(1, tt / 0.3) * np.clip((DUR - tt) / 0.35, 0, 1)
put(room * room_env * 0.012, 0.0)
brown = lowpass(np.cumsum(rng.uniform(-1, 1, n)) * 0.02, 90)
brown -= lowpass(brown, 18)
brown = brown / np.max(np.abs(brown))
board = np.clip((tt - 5.9) / 1.2, 0, 1) * np.clip((T['endCut'] - tt) / 0.05, 0, 1)
put(brown * board * 0.05, 0.0)

# ---- 1. la manchette
whoosh(T['ruleTop'][0], 0.36, 0.25, 600, 2600)
stamp(T['wwHit'], 1.0)
for t in T['sim']:
    put(click(2400, 0.09), t, 5.0)
for i in range(4):
    put(click(2600 + 150 * i, 0.06), T['dateline'][0] + 0.11 * i, 3.2, -0.3)
whoosh(T['breves'], 0.5, 0.18, 900, 3500)

# ---- 2. la planche s'imprime
whoosh(T['camDown'][0], T['camDown'][1] - T['camDown'][0], 0.35)
press(T['seaPass'][0], T['seaPass'][1] - T['seaPass'][0], 0.9, 1.0)
press(T['landPass'][0], T['landPass'][1] - T['landPass'][0], 0.9, 1.08)
for i in range(8):
    t = T['inkStart'] + i * T['inkStep']
    put(click(2200 + (i % 2) * 300, 0.09), t, 4.4, -0.6 + i * 0.17)
tictac(T['caption'][0] + 0.05)
# La presse continue de tourner, plus bas, tant que la planche s'encre.
press_bed_start = T['landPass'][1]
press(press_bed_start, T['labelsOut'][1] - press_bed_start, 0.0, 1.08)

# ---- 3. le plateau
whoosh(T['zoom'][0], T['zoom'][1] - T['zoom'][0], 0.4, 160, 1200)
thump(T['lift'][1], 46, 0.28, 0.45)
for t, pan in zip(T['masts'], (-0.45, 0.0, 0.1)):
    tap(t, 1.0, pan)
tictac(T['card1'])
tap(T['ring'][0], 0.8, 0.1)
whoosh(T['camEast'][0], T['camEast'][1] - T['camEast'][0], 0.2, 200, 900)
tictac(T['card2'])
stamp(T['releve'], 0.55, 0.35)
morse(T['releve'] + 0.12, 'RELEVE', 0.026, 2.4)

# ---- 4. la passe de résolution, la dépêche
boom(T['meet'])
paper_slide(T['sheetIn'][0], T['sheetIn'][1] - T['sheetIn'][0] + 0.12, 1.0)
stamp(T['sheetIn'][1] + 0.01, 0.25, 0.4)
tictac(T['card3'])
stamp(T['sheetStamp'], 0.7, 0.4)

# ---- 5. le carton final
stamp(T['endWW'], 1.0)
for t in T['endSim']:
    put(click(2400, 0.09), t, 5.0)
for i in range(3):
    put(click(2600 + 150 * i, 0.06), T['endDate'][0] + 0.1 * i, 3.2, -0.3)
u0, u1 = T['endUrl']
for i in range(12):
    put(click(3000 + 350 * ((i * 7) % 3), 0.11, q=2.0), u0 + i * (u1 - u0) / 12, 3.6, 0.1)

# ---- mastering : crête à −1 dB, un genou doux
peak = np.max(np.abs(mix))
mix = mix / peak
mix = np.tanh(1.4 * mix) / np.tanh(1.4)
mix *= 10 ** (-1 / 20)
wavfile.write('audio/sfx.wav', SR, (mix * 32767).astype(np.int16))
print('audio/sfx.wav', round(DUR, 2), 's, crête', round(20 * np.log10(np.max(np.abs(mix))), 2), 'dBFS')
