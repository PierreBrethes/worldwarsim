# WorldWarSim — film d'annonce (15 s, 1920 × 1080, 25 i/s)

Une page de journal qui s'imprime, puis devient le plateau. Cinq plans :

| Temps | Plan | Ce qu'il montre |
|---|---|---|
| 0 – 2,4 s | Manchette | le pavé « WW » tombe comme un tampon, « SIM » en Bodoni, les brèves |
| 2,4 – 5,7 s | Planche I | la carte s'imprime en deux passes (mer tramée, terres), les huit nations s'encrent |
| 5,7 – 9,6 s | Plateau | la carte bascule et prend son épaisseur ; trois mouvements (terre, air, mer) ; un relevé dans la portée d'un avant-poste |
| 9,6 – 12,4 s | Dépêche | la passe de résolution, la dépêche du Journal des opérations, le tampon |
| 12,4 – 15 s | Carton | manchette, principe directeur, bureau des engagements, planche de reconnaissance |

Les valeurs visuelles viennent du jeu : `src/styles/tokens.css`, `INK_BY_NATION`, `PALETTE` et
`ARC_COLORS`, `SILHOUETTES`, `airRise`, `HELD_OPACITY`, `Masthead`, `Stamp`. La carte est
reprojetée depuis `public/world.json` avec la projection exacte du jeu (Natural Earth 1, 400 × 208).

## Refaire le film

```bash
npm install d3-geo playwright && npx playwright install chromium
node prep-geo.mjs          # villes, canevas, pays → data/geo.json (lit ../../public/world.json)
python3 prep-raster.py     # isobathes → data/contours.json
./build.sh                 # images, bande son, MP4
```

`build.sh` sert la page en local (les polices ne se chargent pas en `file://`), rend une image par
1/25 s avec Playwright, synthétise la bande son (`sfx.py`, aucun fichier audio) et encode en H.264.

Les polices (Google Fonts, licence OFL) sont déjà dans `assets/fonts`, les planches dans
`assets/sprites` et les drapeaux dans `assets/flags` : copies de `src/emblems` et de
`country-flag-icons`, rien de plus.

Pour regarder sans rendre : `python3 -m http.server 8123` dans ce dossier, puis
`http://127.0.0.1:8123/teaser.html` (le film tourne en boucle) ou `?t=9.8` pour une image fixe.

Un texte se corrige dans `teaser.html` (page, dépêche, carton) ou dans `STATEMENTS` de `teaser.js`
(les trois titres du plateau). Les temps forts sont dans l'objet `T` ; la bande son les relit.
