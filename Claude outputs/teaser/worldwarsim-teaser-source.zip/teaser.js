'use strict';
/*
 * WorldWarSim — film d'annonce, 15 s, 1920 × 1080.
 *
 * Tout l'écran est une seule fonction du temps : `renderAt(t)`. Aucune horloge, aucun état
 * qui traîne d'une image à l'autre — le banc de rendu (render.mjs) appelle t = 0, 1/25, 2/25…
 * et une image se refait à l'identique. Ouvert dans un navigateur, le fichier se joue seul.
 *
 * Les valeurs visuelles viennent du jeu : src/styles/tokens.css, INK_BY_NATION
 * (src/domain/nations.ts), PALETTE et ARC_COLORS (src/map/engine/palette.ts), SILHOUETTES
 * (src/map/engine/silhouettes.ts), airRise (src/map/engine/thread.ts), HELD_OPACITY
 * (src/map/engine/regions.ts), Masthead et Stamp (src/shell/).
 */

const W = 1920, H = 1080, FPS = 25, DURATION = 15;
const K = 4.25, MX = 110, MY = 600; // 1 unité de carte = 4,25 px de page ; la planche est posée en (110, 600)

const C = {
  desk: '#0f0a04', paper: '#e4d8bd', ink: '#2a2118', inkSoft: '#5f5039', inkQuiet: '#4a4436',
  pile1: '#cfc09e', pile2: '#b8ab8c',
  sea: '#a9c5cd', seaInk: '#2c5063', land: '#d5c5a0', side: '#7d6a45', graticule: '#4a4436',
  rim: '#6b4a24', plinthTop: '#c7b48e', plinthBottom: '#5f5039', critical: '#9d4638',
  mineTrace: '#c98a3c', mineDeep: '#9a6524', enemyTrace: '#8f4a3e', enemyProgress: '#9d4638',
};
const INK = {
  france: '#3f5a7d', uk: '#4a4f7a', usa: '#4a7060', ussr: '#9d4638',
  germany: '#6e6a5e', japan: '#a44a5e', italy: '#a86c4a', china: '#b07434',
};
const HELD_OPACITY = 0.72;

// L'ordre d'encrage : l'Europe d'abord, puis le monde, vers l'est, et l'Amérique pour finir.
const NATIONS = [
  { key: 'france', adm: 'FRA', name: 'France', flag: 'FR', cap: 'paris', lbl: 'lblFrance', side: 'left' },
  { key: 'uk', adm: 'GBR', name: 'Royaume-Uni', flag: 'GB', cap: 'london', lbl: 'lblUk', side: 'left' },
  { key: 'germany', adm: 'DEU', name: 'Allemagne', flag: 'DE', cap: 'berlin', lbl: 'lblGermany', side: 'up' },
  { key: 'italy', adm: 'ITA', name: 'Italie', flag: 'IT', cap: 'rome', lbl: 'lblItaly', side: 'down' },
  { key: 'ussr', adm: 'RUS', name: 'URSS', flag: 'SU', cap: 'moscow', lbl: 'lblUssr', side: 'center' },
  { key: 'china', adm: 'CHN', name: 'Chine', flag: 'CN', cap: 'beijing', lbl: 'lblChina', side: 'center' },
  { key: 'japan', adm: 'JPN', name: 'Japon', flag: 'JP', cap: 'tokyo', lbl: 'lblJapan', side: 'right' },
  { key: 'usa', adm: 'USA', name: 'États-Unis', flag: 'US', cap: 'washington', lbl: 'lblUsa', side: 'center' },
];

/* ------------------------------------------------------------------ temps */

const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const seg = (t, a, b) => clamp((t - a) / (b - a));
const lerp = (a, b, u) => a + (b - a) * u;
const eio = (u) => (u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2);
const eo = (u) => 1 - Math.pow(1 - u, 3);
const eo5 = (u) => 1 - Math.pow(1 - u, 5);
const ei = (u) => u * u;

/** Les temps forts. La bande son (sfx.py) lit les mêmes chiffres dans timeline.json. */
const T = {
  ruleTop: [0.06, 0.4], wwHit: 0.46, sim: [0.62, 0.74, 0.86],
  ruleBottom: [0.9, 1.2], dateline: [0.98, 1.5], breves: 1.12,
  camDown: [1.85, 2.85],
  seaPass: [2.3, 2.95], landPass: [2.78, 3.4],
  inkStart: 3.42, inkStep: 0.165, inkDur: 0.34,
  caption: [4.72, 5.3], labelsOut: [5.45, 5.8],
  zoom: [5.7, 7.2], lift: [5.95, 7.05],
  masts: [6.55, 6.7, 6.85],
  land: [6.88, 9.75], air: [7.02, 8.3], sea: [7.16, 14.5],
  card1: 6.95, camEast: [7.95, 8.9], ring: [8.02, 8.42], card2: 8.5, releve: 8.66,
  meet: 9.75, camSheet: [9.55, 10.35], sheetIn: [9.95, 10.32], card3: 10.45, sheetStamp: 10.74,
  endCut: 12.35, endWW: 12.5, endSim: [12.64, 12.74, 12.84],
  endDate: [12.86, 13.2], endChapo: [12.95, 13.4], endBureau: [13.12, 13.34], endUrl: [13.22, 13.62],
  frieze: [13.5, 14.05],
};

/* ------------------------------------------------------------- données */

let GEO, CONT;
const IMG = {};
const PT = {}; // villes et ancres, en px de page
let COUNTRIES = [], OUTLINE, CONTOURS = [], GRATICULE = [];
let NATION_RINGS = {};
let ROUTES = {};

const toPage = (x, y) => [MX + K * x, MY + K * y];

function ringOf(points) {
  const data = new Float64Array(points.length * 2);
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  points.forEach(([x, y], i) => {
    const [px, py] = toPage(x, y);
    data[2 * i] = px; data[2 * i + 1] = py;
    if (px < minX) minX = px; if (px > maxX) maxX = px;
    if (py < minY) minY = py; if (py > maxY) maxY = py;
  });
  return { data, minX, minY, maxX, maxY };
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => img.decode().then(() => resolve(img), () => resolve(img));
    img.onerror = reject;
    img.src = src;
  });
}

async function load() {
  [GEO, CONT] = await Promise.all([
    fetch('data/geo.json').then((r) => r.json()),
    fetch('data/contours.json').then((r) => r.json()),
  ]);
  for (const [k, [x, y]] of Object.entries(GEO.cities)) PT[k] = toPage(x, y);

  COUNTRIES = GEO.countries.map((c) => ({ a: c.a, rings: c.p.map(ringOf) }));
  for (const n of NATIONS) NATION_RINGS[n.key] = COUNTRIES.find((c) => c.a === n.adm).rings;

  const o = GEO.outline; // [lat, xOuest, xEst, y]
  const pts = [];
  for (let i = 0; i < o.length; i++) pts.push([o[i][1], o[i][3]]);
  for (let i = o.length - 1; i >= 0; i--) pts.push([o[i][2], o[i][3]]);
  OUTLINE = ringOf(pts);

  CONTOURS = CONT.levels.map((level) => CONT.lines[String(level)].map(ringOf));
  GRATICULE = GEO.graticule.map(ringOf);

  buildRoutes();

  const sprites = ['france/armor-2', 'france/fighter', 'france/escort',
    'uk/fighter', 'usa/fighter', 'germany/fighter', 'italy/fighter', 'ussr/fighter', 'japan/fighter', 'china/fighter'];
  await Promise.all(sprites.map(async (s) => { IMG[s] = await loadImage(`assets/sprites/${s}.webp`); }));
  for (const n of NATIONS) IMG['flag-' + n.flag] = await loadImage(`assets/flags/${n.flag}.svg`);

  await Promise.all([
    '800 74px "Bodoni Moda"', '700 24px "Bodoni Moda"', 'italic 400 38px "Source Serif 4"', '400 30px "Source Serif 4"',
    '400 17px "Archivo Narrow"', '600 15px "Archivo Narrow"', '700 17px "Archivo Narrow"',
    '400 22px "IBM Plex Mono"', '500 50px "IBM Plex Mono"',
  ].map((f) => document.fonts.load(f)));
  await document.fonts.ready;

  buildDom();
  PATTERNS = buildPatterns();
}

/* -------------------------------------------------------------- caméra */

let CAM = null;

const mixCam = (a, b, u, logZoom = true) => ({
  x: lerp(a.x, b.x, u), y: lerp(a.y, b.y, u),
  z: logZoom ? Math.exp(lerp(Math.log(a.z), Math.log(b.z), u)) : lerp(a.z, b.z, u),
  tilt: lerp(a.tilt, b.tilt, u), oy: lerp(a.oy, b.oy, u),
});

/** Plongée vers un point : la cible avance au rythme du zoom, sinon elle file en travers. */
function zoomCam(a, b, u) {
  const z = Math.exp(lerp(Math.log(a.z), Math.log(b.z), u));
  const w = (1 - a.z / z) / (1 - a.z / b.z);
  return { x: lerp(a.x, b.x, w), y: lerp(a.y, b.y, w), z, tilt: lerp(a.tilt, b.tilt, eio(u)), oy: lerp(a.oy, b.oy, u) };
}

let KEYS;
function cameraKeys() {
  const p3 = PT.camP3, p3b = PT.camP3b, m = PT.meet;
  return {
    P1a: { x: 960, y: 432, z: 1.22, tilt: 0, oy: 0 },
    P1b: { x: 960, y: 470, z: 1.06, tilt: 0, oy: 0 },
    P2a: { x: 960, y: 1080, z: 0.955, tilt: 0, oy: 0 },
    P2b: { x: 960, y: 1080, z: 0.975, tilt: 0, oy: 0 },
    P3a: { x: p3[0], y: p3[1], z: 13, tilt: 0.8, oy: 70 },
    P3c: { x: p3[0] + 2, y: p3[1] - 2, z: 13.8, tilt: 0.8, oy: 70 },
    P3b: { x: p3b[0], y: p3b[1], z: 25, tilt: 0.84, oy: 30 },
    P4: { x: m[0] + 350 / 26, y: m[1] + 3, z: 26, tilt: 0.84, oy: 30 },
    P4b: { x: m[0] + 350 / 27.5 + 0.5, y: m[1] + 3, z: 27.5, tilt: 0.85, oy: 30 },
  };
}

function cameraAt(t) {
  const k = KEYS;
  let cam;
  if (t < T.camDown[0]) cam = mixCam(k.P1a, k.P1b, seg(t, 0, T.camDown[0]));
  else if (t < T.camDown[1]) cam = mixCam(k.P1b, k.P2a, eio(seg(t, ...T.camDown)));
  else if (t < T.zoom[0]) cam = mixCam(k.P2a, k.P2b, seg(t, T.camDown[1], T.zoom[0]));
  else if (t < T.zoom[1]) cam = zoomCam(k.P2b, k.P3a, eio(seg(t, ...T.zoom)));
  else if (t < T.camEast[0]) cam = mixCam(k.P3a, k.P3c, seg(t, T.zoom[1], T.camEast[0]));
  else if (t < T.camEast[1]) cam = mixCam(k.P3c, k.P3b, eio(seg(t, ...T.camEast)));
  else if (t < T.camSheet[0]) cam = k.P3b;
  else if (t < T.camSheet[1]) cam = mixCam(k.P3b, k.P4, eio(seg(t, ...T.camSheet)));
  else cam = mixCam(k.P4, k.P4b, seg(t, T.camSheet[1], T.endCut));

  // Le choc de la passe de résolution : une secousse brève, déterministe.
  const u = seg(t, T.meet, T.meet + 0.32);
  const amp = t >= T.meet ? 9 * Math.pow(1 - u, 2) : 0;
  cam.sx = amp * Math.sin(t * 91.3);
  cam.sy = amp * Math.cos(t * 77.9);
  return cam;
}

function setCamera(cam) {
  const s = Math.sin(cam.tilt), c = Math.cos(cam.tilt);
  const D = 1.45 * W / cam.z;
  const F = cam.z * D;
  const m = H / 2 + 260 - cam.oy;
  CAM = {
    ...cam, s, c, D, F,
    cx: W / 2 + (cam.sx || 0), cy: H / 2 + cam.oy + (cam.sy || 0),
    // Au-delà, tout est sous le cadre : on coupe là, avant que la perspective ne s'affole.
    yClip: cam.tilt > 1e-4 ? (m * D) / (F * c + m * s) : 1e9,
  };
}

function proj(px, py, z = 0) {
  const X = px - CAM.x, Y = py - CAM.y;
  const k = CAM.F / (CAM.D - Y * CAM.s - z * CAM.c);
  return [CAM.cx + X * k, CAM.cy + (Y * CAM.c - z * CAM.s) * k, k];
}

/* ------------------------------------------------------- tracés de carte */

function clipPolyY(a, ymax) {
  const out = [];
  const n = a.length / 2;
  for (let i = 0; i < n; i++) {
    const x1 = a[2 * i], y1 = a[2 * i + 1];
    const j = (i + 1) % n;
    const x2 = a[2 * j], y2 = a[2 * j + 1];
    const in1 = y1 <= ymax, in2 = y2 <= ymax;
    if (in1) out.push(x1, y1);
    if (in1 !== in2) out.push(x1 + ((x2 - x1) * (ymax - y1)) / (y2 - y1), ymax);
  }
  return out.length >= 6 ? out : null;
}

function clipLineY(a, ymax) {
  const pieces = [];
  let cur = [];
  const n = a.length / 2;
  for (let i = 0; i < n; i++) {
    const x = a[2 * i], y = a[2 * i + 1];
    if (y <= ymax) {
      if (cur.length === 0 && i > 0) {
        const px = a[2 * i - 2], py = a[2 * i - 1];
        cur.push(px + ((x - px) * (ymax - py)) / (y - py), ymax);
      }
      cur.push(x, y);
    } else if (cur.length) {
      const px = a[2 * i - 2], py = a[2 * i - 1];
      cur.push(px + ((x - px) * (ymax - py)) / (y - py), ymax);
      pieces.push(cur); cur = [];
    }
  }
  if (cur.length >= 4) pieces.push(cur);
  return pieces;
}

/** Le cadre écran d'une boîte de page : une homographie garde la boîte convexe, donc ses quatre coins suffisent. */
function visible(r, z, margin = 40) {
  const ymax = CAM.y + CAM.yClip;
  if (r.minY > ymax) return false;
  const y2 = Math.min(r.maxY, ymax);
  let x0 = Infinity, x1 = -Infinity, yy0 = Infinity, yy1 = -Infinity;
  for (const [px, py] of [[r.minX, r.minY], [r.maxX, r.minY], [r.minX, y2], [r.maxX, y2]]) {
    const [sx, sy] = proj(px, py, z);
    if (sx < x0) x0 = sx; if (sx > x1) x1 = sx; if (sy < yy0) yy0 = sy; if (sy > yy1) yy1 = sy;
  }
  return !(x1 < -margin || x0 > W + margin || yy1 < -margin || yy0 > H + margin);
}

function addRing(g, r, z, closed = true) {
  if (!visible(r, z)) return;
  const ymax = CAM.y + CAM.yClip;
  const { x, y, D, F, s, c, cx, cy } = CAM;
  const draw = (a) => {
    const n = a.length;
    for (let i = 0; i < n; i += 2) {
      const X = a[i] - x, Y = a[i + 1] - y;
      const k = F / (D - Y * s - z * c);
      const sx = cx + X * k, sy = cy + (Y * c - z * s) * k;
      if (i === 0) g.moveTo(sx, sy); else g.lineTo(sx, sy);
    }
    if (closed) g.closePath();
  };
  if (r.maxY <= ymax) draw(r.data);
  else if (closed) { const a = clipPolyY(r.data, ymax); if (a) draw(a); }
  else for (const piece of clipLineY(r.data, ymax)) draw(piece);
}

/** Échelle locale (px d'écran par px de page) au centre d'une boîte : sert aux épaisseurs. */
function scaleAt(r, z) {
  const ymax = CAM.y + CAM.yClip;
  return proj((r.minX + r.maxX) / 2, Math.min((r.minY + r.maxY) / 2, ymax), z)[2];
}

/* --------------------------------------------------------- trames */

let PATTERNS;
const BAND_COVERAGE = [0, 0.06, 0.11, 0.17, 0.25]; // de la côte au large : plus profond, plus d'encre

function dotTile(coverage, ink, size = 8) {
  const t = document.createElement('canvas');
  t.width = size; t.height = size;
  const g = t.getContext('2d');
  if (coverage > 0) {
    const pitch = size / Math.SQRT2;
    const r = pitch * Math.sqrt(coverage / Math.PI);
    g.fillStyle = ink;
    for (const [x, y] of [[0, 0], [size, 0], [0, size], [size, size], [size / 2, size / 2]]) {
      g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
    }
  }
  return t;
}

function buildPatterns() {
  const ctx = document.getElementById('map').getContext('2d');
  return BAND_COVERAGE.map((cov) => (cov > 0 ? ctx.createPattern(dotTile(cov, C.seaInk), 'repeat') : null));
}

/**
 * Similigravure à une encre, découpée : le matériel devient une photo de presse tramée,
 * collée sur un carton à liseré d'encre. Le ton est normalisé planche par planche (5e et
 * 95e centiles), sinon le camouflage sombre d'un char noie la trame dans un aplat.
 */
const HALFTONE = new Map();
function halftone(img, width, pitch, ink = C.ink) {
  const key = `${img.src}|${width}|${pitch}`;
  if (HALFTONE.has(key)) return HALFTONE.get(key);
  const height = Math.round((width * img.naturalHeight) / img.naturalWidth);
  const pad = Math.ceil(pitch) + 5;
  const src = document.createElement('canvas');
  src.width = width; src.height = height;
  const sg = src.getContext('2d', { willReadFrequently: true });
  sg.filter = `blur(${(pitch * 0.3).toFixed(2)}px)`;
  sg.drawImage(img, 0, 0, width, height);
  const px = sg.getImageData(0, 0, width, height).data;
  const lums = [];
  for (let i = 0; i < px.length; i += 16) if (px[i + 3] > 128) lums.push((0.2126 * px[i] + 0.7152 * px[i + 1] + 0.0722 * px[i + 2]) / 255);
  lums.sort((a, b) => a - b);
  const lo = lums[Math.floor(lums.length * 0.05)] ?? 0, hi = lums[Math.floor(lums.length * 0.95)] ?? 1;

  const out = document.createElement('canvas');
  out.width = width + 2 * pad; out.height = height + 2 * pad;
  const og = out.getContext('2d');
  // Le carton : la silhouette, dilatée, en encre puis en papier — il reste un liseré.
  const mask = (color) => {
    const m = document.createElement('canvas');
    m.width = width; m.height = height;
    const mg = m.getContext('2d');
    mg.drawImage(img, 0, 0, width, height);
    mg.globalCompositeOperation = 'source-in';
    mg.fillStyle = color; mg.fillRect(0, 0, width, height);
    return m;
  };
  const inkMask = mask(ink), paperMask = mask(C.paper);
  for (let a = 0; a < 16; a++) {
    const ang = (a / 16) * Math.PI * 2;
    og.drawImage(inkMask, pad + Math.cos(ang) * 3.4, pad + Math.sin(ang) * 3.4);
  }
  for (let a = 0; a < 16; a++) {
    const ang = (a / 16) * Math.PI * 2;
    og.drawImage(paperMask, pad + Math.cos(ang) * 2.1, pad + Math.sin(ang) * 2.1);
  }
  og.drawImage(paperMask, pad, pad);
  og.fillStyle = ink;
  const cell = pitch * Math.SQRT2;
  let row = 0;
  for (let gy = 0; gy <= height; gy += cell / 2, row++) {
    for (let gx = row % 2 ? cell / 2 : 0; gx <= width; gx += cell) {
      const ix = Math.min(width - 1, Math.round(gx)), iy = Math.min(height - 1, Math.round(gy));
      const i = (iy * width + ix) * 4;
      const a = px[i + 3] / 255;
      if (a < 0.05) continue;
      const lum = (0.2126 * px[i] + 0.7152 * px[i + 1] + 0.0722 * px[i + 2]) / 255;
      const tone = Math.pow(clamp((hi - lum) / Math.max(0.05, hi - lo)), 1.15);
      const cov = (0.035 + 0.7 * tone) * a;
      const r = pitch * Math.sqrt(cov / Math.PI);
      if (r < 0.25) continue;
      og.beginPath(); og.arc(gx + pad, gy + pad, r, 0, Math.PI * 2); og.fill();
    }
  }
  const result = { canvas: out, w: out.width, h: out.height, pad };
  HALFTONE.set(key, result);
  return result;
}

/* -------------------------------------------------------- itinéraires */

/** airRise (src/map/engine/thread.ts) : 18 % de la corde, entre 4 et 24 unités. */
const airRise = (chord) => Math.min(24, Math.max(4, chord * 0.18));

function straight(a, b, n, lift = 0) {
  const pts = [];
  for (let i = 0; i <= n; i++) {
    const u = i / n;
    pts.push({ x: lerp(a[0], b[0], u), y: lerp(a[1], b[1], u), h: lift * Math.sin(Math.PI * u) });
  }
  let len = 0;
  pts[0].d = 0;
  for (let i = 1; i < pts.length; i++) {
    len += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
    pts[i].d = len;
  }
  pts.forEach((p) => (p.u = p.d / len));
  return pts;
}

function buildRoutes() {
  const chord = Math.hypot(PT.milan[0] - PT.lyon[0], PT.milan[1] - PT.lyon[1]) / K;
  ROUTES = {
    land: straight(PT.paris, PT.meet, 40),
    air: straight(PT.lyon, PT.milan, 48, airRise(chord) * K),
    sea: straight(PT.toulon, PT.algiers, 40),
    enemy: straight(PT.mannheim, PT.meet, 40),
  };
  // Le cercle de portée de l'avant-poste, et l'heure où la colonne adverse y entre.
  RING = { c: PT.nancy, r: 1.75 * K };
  const e = ROUTES.enemy;
  let enter = 0;
  for (let i = 1; i < e.length; i++) {
    if (Math.hypot(e[i].x - RING.c[0], e[i].y - RING.c[1]) <= RING.r) {
      const a = e[i - 1], b = e[i];
      const da = Math.hypot(a.x - RING.c[0], a.y - RING.c[1]), db = Math.hypot(b.x - RING.c[0], b.y - RING.c[1]);
      enter = lerp(a.u, b.u, (da - RING.r) / (da - db));
      break;
    }
  }
  RING.enter = enter;
  // La tête franchit le cercle à 8,45 s et touche la nôtre à l'instant de la passe.
  ENEMY_T0 = (8.45 - T.meet * enter) / (1 - enter);
}
let RING, ENEMY_T0;

function routeAt(route, u) {
  u = clamp(u);
  for (let i = 1; i < route.length; i++) {
    if (route[i].u >= u) {
      const a = route[i - 1], b = route[i];
      const v = (u - a.u) / (b.u - a.u || 1);
      return { x: lerp(a.x, b.x, v), y: lerp(a.y, b.y, v), h: lerp(a.h, b.h, v) };
    }
  }
  return route[route.length - 1];
}

/** Sous-chemin [u0, u1] d'un itinéraire, projeté à la surface du plateau. */
function routePath(g, route, u0, u1, z0, withHeight = true) {
  if (u1 <= u0) return;
  const pts = [routeAt(route, u0)];
  for (const p of route) if (p.u > u0 && p.u < u1) pts.push(p);
  pts.push(routeAt(route, u1));
  pts.forEach((p, i) => {
    const [sx, sy] = proj(p.x, p.y, z0 + (withHeight ? p.h : 0));
    if (i === 0) g.moveTo(sx, sy); else g.lineTo(sx, sy);
  });
}

/* ------------------------------------------------------------ dessin */

const cv = document.getElementById('map');
const ctx = cv.getContext('2d');
const layerA = document.createElement('canvas'); layerA.width = W; layerA.height = H;
const layerB = document.createElement('canvas'); layerB.width = W; layerB.height = H;
const layerD = document.createElement('canvas'); layerD.width = W; layerD.height = H;
const gA = layerA.getContext('2d'), gB = layerB.getContext('2d'), gD = layerD.getContext('2d');

function drawPage(g, st) {
  if (st.pageAlpha <= 0) return;
  g.save();
  g.globalAlpha = st.pageAlpha;
  const sheet = (dx, dy, fill, stroke) => {
    const pts = [[dx, dy], [1920 + dx, dy], [1920 + dx, 1700 + dy], [dx, 1700 + dy]];
    g.beginPath();
    pts.forEach(([x, y], i) => { const [sx, sy] = proj(x, y, 0); i ? g.lineTo(sx, sy) : g.moveTo(sx, sy); });
    g.closePath();
    g.fillStyle = fill; g.fill();
    if (stroke) { g.strokeStyle = stroke; g.lineWidth = 1; g.stroke(); }
  };
  sheet(16, 14, C.pile2, C.inkSoft);
  sheet(8, 7, C.pile1, C.inkSoft);
  sheet(0, 0, C.paper, C.ink);
  // La trame du papier (.paper) : un filet à 45° tous les 5 px, à 5,5 % d'encre.
  if (st.hatch > 0 && CAM.z < 2.5) {
    g.save();
    g.beginPath();
    [[0, 0], [1920, 0], [1920, 1700], [0, 1700]].forEach(([x, y], i) => { const [sx, sy] = proj(x, y, 0); i ? g.lineTo(sx, sy) : g.moveTo(sx, sy); });
    g.closePath(); g.clip();
    g.beginPath();
    const step = 5 * Math.SQRT2;
    for (let c0 = -1700; c0 < 1920; c0 += step) {
      const [ax, ay] = proj(c0, 0, 0), [bx, by] = proj(c0 + 1700, 1700, 0);
      g.moveTo(ax, ay); g.lineTo(bx, by);
    }
    g.strokeStyle = `rgba(42,33,24,${0.055 * st.hatch})`;
    g.lineWidth = Math.max(0.6, CAM.z);
    g.stroke();
    g.restore();
  }
  g.restore();
}

function outlinePath(g, z) { g.beginPath(); addRing(g, OUTLINE, z); }

function drawSea(g, st) {
  const zs = st.Hb;
  // Socle en tranche de papier : la carte sort de la page.
  if (st.Hb > 0.05) {
    outlinePath(g, 0);
    const [, yTop] = proj(MX + 850, MY + 884, zs), [, yBot] = proj(MX + 850, MY + 884, 0);
    const grad = g.createLinearGradient(0, yTop, 0, yBot + 1);
    grad.addColorStop(0, C.plinthTop); grad.addColorStop(1, C.plinthBottom);
    g.fillStyle = grad; g.fill();
    g.strokeStyle = 'rgba(42,33,24,.6)'; g.lineWidth = 1; g.stroke();
  }
  outlinePath(g, zs);
  g.fillStyle = C.sea; g.fill();

  // Planche imprimée : la profondeur se lit à la densité d'une trame à 45° (fiche 10).
  if (st.halftone > 0) {
    gD.setTransform(1, 0, 0, 1, 0, 0);
    gD.clearRect(0, 0, W, H);
    gD.save();
    outlinePath(gD, zs); gD.clip();
    const m = new DOMMatrix([CAM.z, 0, 0, CAM.z, CAM.cx - CAM.x * CAM.z, CAM.cy - CAM.y * CAM.z]);
    PATTERNS.forEach((p) => p && p.setTransform(m));
    gD.fillStyle = PATTERNS[4]; gD.fillRect(0, 0, W, H);
    for (let i = 3; i >= 0; i--) {
      gD.beginPath();
      for (const r of CONTOURS[i]) addRing(gD, r, zs);
      gD.globalCompositeOperation = 'destination-out';
      gD.fillStyle = '#000'; gD.fill('evenodd');
      gD.globalCompositeOperation = 'source-over';
      if (PATTERNS[i]) { gD.fillStyle = PATTERNS[i]; gD.fill('evenodd'); }
    }
    gD.restore();
    g.save(); g.globalAlpha = st.halftone; g.drawImage(layerD, 0, 0); g.restore();
  }

  // Canevas, sous les terres.
  g.save();
  outlinePath(g, zs); g.clip();
  g.beginPath();
  for (const r of GRATICULE) addRing(g, r, zs, false);
  g.strokeStyle = `rgba(74,68,54,${st.graticule})`; g.lineWidth = 1; g.stroke();
  g.restore();

  // Lavis côtier (coastal-wash.ts) : l'encre part du trait de côte et s'éteint vers le large.
  if (st.wash > 0) {
    for (const [width, alpha] of [[0.85, 0.09], [0.5, 0.1], [0.22, 0.12]]) {
      g.strokeStyle = `rgba(44,80,99,${alpha * st.wash})`;
      g.lineJoin = 'round';
      for (const country of COUNTRIES) for (const r of country.rings) {
        if (!visible(r, zs, 120)) continue;
        g.beginPath(); addRing(g, r, zs);
        g.lineWidth = 2 * width * K * scaleAt(r, zs);
        g.stroke();
      }
    }
  }

  // Isobathes à l'encre.
  const iso = st.isobaths;
  for (let i = 0; i < CONTOURS.length; i++) {
    const a = iso[i];
    if (a <= 0) continue;
    g.beginPath();
    for (const r of CONTOURS[i]) addRing(g, r, zs);
    g.strokeStyle = `rgba(44,80,99,${a})`; g.lineWidth = st.isoWidth; g.stroke();
  }
}

function drawLand(g, st) {
  const zs = st.Hb, zt = st.Hb + st.T;
  if (st.T > 0.02) {
    g.beginPath();
    for (const country of COUNTRIES) for (const r of country.rings) addRing(g, r, zs);
    g.fillStyle = C.side; g.fill('nonzero');
  }
  g.beginPath();
  for (const country of COUNTRIES) for (const r of country.rings) addRing(g, r, zt);
  g.fillStyle = C.land; g.fill('nonzero');
}

function drawBorders(g, st) {
  const zt = st.Hb + st.T;
  g.beginPath();
  for (const country of COUNTRIES) for (const r of country.rings) addRing(g, r, zt);
  g.strokeStyle = 'rgba(42,33,24,.62)'; g.lineWidth = st.borderWidth; g.lineJoin = 'round'; g.stroke();
  outlinePath(g, st.Hb);
  g.strokeStyle = C.rim; g.lineWidth = st.rimWidth; g.stroke();
}

function drawInks(g, st) {
  const zt = st.Hb + st.T;
  NATIONS.forEach((n, i) => {
    const u = st.inks[i];
    if (u <= 0) return;
    g.save();
    if (u < 1) {
      // L'encre s'étend depuis la capitale.
      const [cx, cy] = proj(PT[n.cap][0], PT[n.cap][1], zt);
      let reach = 0;
      for (const r of NATION_RINGS[n.key]) for (const [px, py] of [[r.minX, r.minY], [r.maxX, r.minY], [r.minX, r.maxY], [r.maxX, r.maxY]]) {
        const [sx, sy] = proj(px, py, zt);
        reach = Math.max(reach, Math.hypot(sx - cx, sy - cy));
      }
      g.beginPath(); g.arc(cx, cy, eo(u) * (reach + 12), 0, Math.PI * 2); g.clip();
    }
    g.beginPath();
    for (const r of NATION_RINGS[n.key]) addRing(g, r, zt);
    g.globalAlpha = HELD_OPACITY * Math.min(1, u * 2.2);
    g.fillStyle = INK[n.key]; g.fill('nonzero');
    g.restore();
  });
}

/** Révélation d'une plaque au passage du rouleau, avec son défaut de repérage. */
function printPass(src, u, off) {
  if (u <= 0) return;
  if (u >= 1 && Math.abs(off[0]) < 0.05 && Math.abs(off[1]) < 0.05) { ctx.drawImage(src, 0, 0); return; }
  const g = src.getContext('2d');
  const edge = lerp(MX - 120, MX + 1700 + 120, eio(u));
  const [xe] = proj(edge, MY, 0);
  const soft = 110 * CAM.z;
  g.save();
  g.globalCompositeOperation = 'destination-in';
  const grad = g.createLinearGradient(xe - soft, 0, xe, 0);
  grad.addColorStop(0, 'rgba(0,0,0,1)'); grad.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = grad; g.fillRect(0, 0, W, H);
  g.restore();
  ctx.drawImage(src, off[0], off[1]);
}

/* ----------------------------------------------------- plateau de jeu */

function drawThread(route, uShown, uDone, z0, kind, uStart = 0) {
  if (uShown <= uStart) return;
  const mine = kind !== 'enemy';
  const color = mine ? C.mineTrace : C.enemyTrace;
  const width = mine ? 4.4 : 3.6;
  ctx.save();
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  if (route.air) {
    // L'ombre portée au sol d'un arc aérien.
    ctx.beginPath(); routePath(ctx, route, uStart, uShown, z0, false);
    ctx.setLineDash([2, 7]); ctx.strokeStyle = 'rgba(42,33,24,.35)'; ctx.lineWidth = 2; ctx.stroke();
    ctx.setLineDash([]);
  }
  // Le parcouru : trait plein. Le reste à faire : tirets (3/5 px dans le jeu, doublés pour l'écran).
  ctx.beginPath(); routePath(ctx, route, uStart, Math.min(uDone, uShown), z0);
  ctx.strokeStyle = mine ? C.mineDeep : C.enemyProgress; ctx.lineWidth = width + 2.2; ctx.globalAlpha = 0.55; ctx.stroke();
  ctx.globalAlpha = 1; ctx.strokeStyle = color; ctx.lineWidth = width; ctx.stroke();
  if (uShown > uDone) {
    ctx.beginPath(); routePath(ctx, route, Math.max(uStart, uDone), uShown, z0);
    ctx.setLineDash([8, 10]); ctx.strokeStyle = color; ctx.globalAlpha = 0.85; ctx.lineWidth = width; ctx.stroke();
  }
  ctx.restore();
}

function drawSprite(img, width, pitch, sx, sy, anchor, alpha = 1, scale = 1) {
  if (alpha <= 0) return;
  const h = halftone(img, width, pitch);
  const w = h.w * scale, hh = h.h * scale;
  let x = sx - w / 2, y = anchor === 'foot' ? sy - hh + h.pad * scale : sy - hh / 2;
  ctx.save(); ctx.globalAlpha = alpha;
  ctx.drawImage(h.canvas, x, y, w, hh);
  ctx.restore();
}

function drawMast(p, z, u, ink) {
  if (u <= 0) return;
  const [sx, sy] = proj(p[0], p[1], z);
  const hgt = 58 * eo(u);
  ctx.save();
  ctx.fillStyle = C.ink;
  ctx.beginPath(); ctx.ellipse(sx, sy, 7, 3, 0, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = C.ink; ctx.lineWidth = 2.4;
  ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx, sy - hgt); ctx.stroke();
  if (u > 0.5) {
    const f = eo(seg(u, 0.5, 1));
    ctx.fillStyle = ink; ctx.fillRect(sx + 1, sy - hgt, 22 * f, 14);
    ctx.strokeStyle = C.ink; ctx.lineWidth = 1.2; ctx.strokeRect(sx + 1, sy - hgt, 22 * f, 14);
  }
  ctx.restore();
  return { head: [sx, sy - hgt], foot: [sx, sy] };
}

/** Silhouette de domaine (silhouettes.ts) : ce que le brouillard laisse voir, le milieu et rien d'autre. */
const SILHOUETTE_LAND = [[[-9, 2], [0, 6], [9, 2], [0, -2]]];
function drawSilhouette(sx, sy, size, alpha) {
  const k = size / 20;
  ctx.save(); ctx.globalAlpha = alpha;
  ctx.beginPath();
  for (const poly of SILHOUETTE_LAND) poly.forEach(([x, y], i) => {
    const px = sx + x * k, py = sy + (y - 6) * k * 1.25;
    i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
  });
  ctx.closePath();
  ctx.fillStyle = C.enemyTrace; ctx.fill();
  ctx.strokeStyle = C.ink; ctx.lineWidth = 1.5; ctx.stroke();
  ctx.restore();
}

function drawRing(z, u) {
  if (u <= 0) return;
  const n = 120, r = RING.r * eo(u);
  ctx.save();
  ctx.beginPath();
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2;
    const [sx, sy] = proj(RING.c[0] + Math.cos(a) * r, RING.c[1] + Math.sin(a) * r, z);
    i ? ctx.lineTo(sx, sy) : ctx.moveTo(sx, sy);
  }
  ctx.fillStyle = 'rgba(42,33,24,.05)'; ctx.fill();
  ctx.setLineDash([12, 9]); ctx.strokeStyle = 'rgba(42,33,24,.7)'; ctx.lineWidth = 2.2; ctx.stroke();
  ctx.restore();
}

function drawEnemy(t, z) {
  if (t < 8.4 || t > 10.5) return;
  const v = clamp((t - ENEMY_T0) / (T.meet - ENEMY_T0));
  if (v <= RING.enter) return;
  const fade = 1 - seg(t, 10.0, 10.45);
  const e = ROUTES.enemy;
  // Le tronçon commence à l'entrée dans la portée : avant, il n'existe pas pour nous.
  ctx.save();
  ctx.globalAlpha = fade;
  drawThread(e, v, v, z, 'enemy', RING.enter);
  ctx.restore();
  // Le cap estimé, prolongé en pointillé : une estimation, pas une destination.
  const head = routeAt(e, v);
  const dir = [e[e.length - 1].x - e[0].x, e[e.length - 1].y - e[0].y];
  const len = Math.hypot(dir[0], dir[1]);
  const reachCap = 1.5 * K;
  ctx.save();
  for (let i = 1; i <= 9; i++) {
    const f = i / 9;
    const [sx, sy] = proj(head.x + (dir[0] / len) * reachCap * f, head.y + (dir[1] / len) * reachCap * f, z);
    ctx.globalAlpha = fade * (1 - f) * 0.9 * (t >= T.meet ? 0 : 1);
    ctx.fillStyle = C.enemyTrace;
    ctx.beginPath(); ctx.arc(sx, sy, 2.6, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
  const [hx, hy] = proj(head.x, head.y, z);
  drawSilhouette(hx, hy, 46, fade);
  return [hx, hy];
}

function drawBurst(t, z) {
  const u = seg(t, T.meet, T.meet + 0.6);
  if (u <= 0 || u >= 1) return;
  const [sx, sy] = proj(PT.meet[0], PT.meet[1], z);
  ctx.save();
  for (const [delay, max, w] of [[0, 190, 5], [0.14, 120, 3]]) {
    const v = seg(u, delay, 1);
    if (v <= 0) continue;
    ctx.globalAlpha = (1 - v) * 0.9;
    ctx.strokeStyle = C.ink; ctx.lineWidth = w * (1 - v) + 1;
    ctx.beginPath(); ctx.ellipse(sx, sy, 14 + max * eo5(v), (14 + max * eo5(v)) * 0.72, 0, 0, Math.PI * 2); ctx.stroke();
  }
  // Une éclaboussure de trame, comme une encre trop chargée.
  ctx.fillStyle = C.ink;
  for (let i = 0; i < 70; i++) {
    const a = i * 2.39996, d = 12 + ((i * 37) % 97) * 1.1 * eo(u);
    const r = (2.6 - ((i * 13) % 7) * 0.25) * (1 - u);
    if (r <= 0.2) continue;
    ctx.globalAlpha = 0.9 * (1 - u);
    ctx.beginPath(); ctx.arc(sx + Math.cos(a) * d, sy + Math.sin(a) * d * 0.72, r, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
}

/* ------------------------------------------------------------- DOM */

const $ = (id) => document.getElementById(id);
const CALLOUTS = [];
const TAGS = {};

function wordmark(el, size) {
  el.innerHTML = '';
  const ww = document.createElement('span');
  ww.className = 'ww'; ww.textContent = 'WW';
  Object.assign(ww.style, {
    fontSize: size + 'px',
    padding: `${Math.round(size * 0.14)}px ${Math.round(size * 0.16)}px ${Math.round(size * 0.1)}px`,
  });
  const sim = document.createElement('span');
  sim.className = 'sim';
  Object.assign(sim.style, { fontSize: size + 'px', marginLeft: Math.round(size * 0.16) + 'px' });
  for (const ch of 'SIM') { const s = document.createElement('span'); s.textContent = ch; sim.appendChild(s); }
  el.append(ww, sim);
  return { ww, letters: [...sim.children] };
}

/** tiltOf (src/shell/Stamp.tsx) : ±1°, tiré du texte, jamais zéro — le même mot penche toujours pareil. */
function tiltOf(label) {
  const hash = [...label].reduce((sum, letter) => (sum * 31 + letter.charCodeAt(0)) >>> 0, 7);
  const tenths = (hash % 20) - 10;
  return (tenths < 0 ? tenths : tenths + 1) / 10;
}

const SITES = [
  { key: 'paris', text: 'quartier général', at: () => T.masts[0], side: 'left' },
  { key: 'lyon', text: 'aérodrome', at: () => T.masts[1], side: 'right' },
  { key: 'toulon', text: 'port', at: () => T.masts[2], side: 'right' },
  { key: 'nancy', text: 'avant-poste', at: () => T.ring[0], side: 'below' },
];

let WM1, WM2;
function buildDom() {
  WM1 = wordmark($('wm1'), 200);
  WM2 = wordmark($('wm2'), 236);
  const labels = $('labels');
  for (const n of NATIONS) {
    const el = document.createElement('div');
    el.className = 'tag paper';
    el.innerHTML = `<img src="assets/flags/${n.flag}.svg" alt=""><span>${n.name}</span>`;
    labels.appendChild(el);
    CALLOUTS.push(el);
  }
  for (const site of SITES) {
    const el = document.createElement('div');
    el.className = 'tag small paper';
    el.textContent = site.text;
    labels.appendChild(el);
    TAGS[site.key] = el;
  }
  const rel = document.createElement('div');
  rel.id = 'releve';
  rel.innerHTML = `<span class="stamp critical" style="transform: rotate(${tiltOf('relevé')}deg)">relevé</span>
    <div class="note paper mono">14:05 · cap ouest · arrivée estimée 16:40</div>`;
  labels.appendChild(rel);
  $('sheetStamp').style.setProperty('--tilt', tiltOf('assaut mené') + 'deg');
}

const STATEMENTS = [
  { at: T.card1, eyebrow: 'mouvements — terre, mer, air', day: 'saison 1 — jour 2 sur 7', lines: ['Projeter', 'de la force.'] },
  { at: T.card2, eyebrow: 'brouillard — détection passive', day: 'saison 1 — jour 4 sur 7', lines: ['L’information', 'est chère.'] },
  { at: T.card3, eyebrow: 'passe de résolution', day: 'saison 1 — jour 5 sur 7', lines: ['Tout engagement', 'est irréversible.'] },
];

function setWipe(el, u, fromLeft = true) {
  const p = (1 - clamp(u)) * 100;
  el.style.clipPath = fromLeft ? `inset(-20% ${p}% -20% 0)` : `inset(-20% 0 -20% ${p}%)`;
}

function stampStyle(el, t, hit, baseRotate) {
  const u = seg(t, hit - 0.14, hit);
  const after = seg(t, hit, hit + 0.14);
  let s = lerp(1.85, 1, ei(u));
  if (t >= hit) s = 1 - 0.035 * Math.sin(after * Math.PI);
  el.style.opacity = t < hit - 0.14 ? 0 : Math.min(1, u * 2.5);
  el.style.transform = `rotate(${baseRotate}deg) scale(${s})`;
}

function updateDom(t, st) {
  // La page imprimée suit la caméra (affine tant que le plateau ne bascule pas).
  const page = $('page');
  page.style.transform = `matrix(${CAM.z},0,0,${CAM.z},${CAM.cx - CAM.x * CAM.z},${CAM.cy - CAM.y * CAM.z})`;
  page.style.opacity = st.pageText;

  // Manchette.
  for (const [id, span] of [['r3', T.ruleTop], ['r1a', [T.ruleTop[0] + 0.05, T.ruleTop[1] + 0.05]], ['r1b', T.ruleBottom]]) {
    $(id).style.transform = `scaleX(${eio(seg(t, ...span))})`;
  }
  stampStyle(WM1.ww, t, T.wwHit, -2);
  WM1.letters.forEach((el, i) => {
    const u = seg(t, T.sim[i] - 0.06, T.sim[i] + 0.04);
    el.style.opacity = u > 0 ? 1 : 0;
    el.style.transform = `translateY(${(-0.1 * (1 - eo(u))).toFixed(3)}em)`;
  });
  setWipe($('dl1'), eo(seg(t, ...T.dateline)));
  setWipe($('dr1'), eo(seg(t, T.dateline[0] + 0.12, T.dateline[1] + 0.12)));
  document.querySelectorAll('.breve').forEach((el, i) => {
    const u = eo(seg(t, T.breves + i * 0.08, T.breves + i * 0.08 + 0.4));
    el.style.opacity = u; el.style.transform = `translateY(${(1 - u) * 14}px)`;
  });
  const frame = eo(seg(t, 1.25, 1.7));
  $('plate-frame').style.opacity = frame; $('plate-head').style.opacity = frame;
  setWipe($('caption'), eo(seg(t, ...T.caption)));

  // Légendes de la planche.
  NATIONS.forEach((n, i) => {
    const el = CALLOUTS[i];
    const a = clamp((st.inks[i] - 0.25) * 2.5) * (1 - seg(t, ...T.labelsOut));
    el.style.opacity = a;
    if (a <= 0) return;
    const [sx, sy] = proj(PT[n.lbl][0], PT[n.lbl][1], st.Hb + st.T);
    const tx = { left: '-100%', right: '0%', up: '-50%', down: '-50%', center: '-50%' }[n.side];
    const ty = { left: '-50%', right: '-50%', up: '-100%', down: '0%', center: '-50%' }[n.side];
    el.style.transform = `translate(${sx.toFixed(1)}px, ${sy.toFixed(1)}px) translate(${tx}, ${ty}) scale(${lerp(0.94, 1, eo(clamp(a)))})`;
  });

  // Mâts du plateau.
  for (const site of SITES) {
    const el = TAGS[site.key];
    const m = st.masts[site.key];
    const at = site.at();
    const a = m ? eo(seg(t, at + 0.12, at + 0.32)) * (1 - seg(t, 9.85, 10.15)) : 0;
    el.style.opacity = a;
    if (!m) continue;
    const [hx, hy] = m.head, [fx, fy] = m.foot;
    el.style.transform = site.side === 'right' ? `translate(${(hx + 30).toFixed(1)}px, ${(hy - 3).toFixed(1)}px)`
      : site.side === 'left' ? `translate(${(hx - 10).toFixed(1)}px, ${(hy - 3).toFixed(1)}px) translate(-100%, 0)`
      : `translate(${(fx - 14).toFixed(1)}px, ${(fy + 10).toFixed(1)}px) translate(-100%, 0)`;
  }

  // Le relevé.
  const rel = $('releve');
  const relA = st.enemyHead ? seg(t, T.releve - 0.2, T.releve - 0.05) * (1 - seg(t, 9.6, 9.85)) : 0;
  rel.style.opacity = relA;
  if (st.enemyHead) {
    rel.style.transform = `translate(${(st.enemyHead[0] + 46).toFixed(1)}px, ${(st.enemyHead[1] - 150).toFixed(1)}px)`;
    const stamp = rel.querySelector('.stamp');
    stampStyle(stamp, t, T.releve, tiltOf('relevé'));
    rel.querySelector('.note').style.opacity = seg(t, T.releve + 0.05, T.releve + 0.25);
  }

  // Le cartouche de titre.
  const card = $('card');
  const cardIn = eo(seg(t, T.card1, T.card1 + 0.3));
  card.style.opacity = t < T.endCut ? cardIn : 0;
  card.style.transform = `translateX(${(1 - cardIn) * -70}px)`;
  let k = 0;
  for (let i = 0; i < STATEMENTS.length; i++) if (t >= STATEMENTS[i].at) k = i;
  const cur = STATEMENTS[k];
  $('cardEyebrow').textContent = cur.eyebrow;
  $('cardDay').textContent = cur.day;
  const lA = $('lineA'), lB = $('lineB');
  lA.textContent = cur.lines[0]; lB.textContent = cur.lines[1];
  lB.style.top = '78px';
  const inU = seg(t, cur.at + 0.03, cur.at + 0.4);
  setWipe(lA, eo(inU * 1.6));
  setWipe(lB, eo(seg(inU, 0.25, 1)));
  const next = STATEMENTS[k + 1];
  const outU = next ? eo(seg(t, next.at - 0.22, next.at)) : 0;
  for (const el of [lA, lB]) { el.style.opacity = 1 - outU; el.style.transform = `translateY(${(-14 * outU).toFixed(1)}px)`; }
  setWipe($('cardEyebrow'), eo(seg(t, cur.at, cur.at + 0.25)));

  // La dépêche.
  const sheet = $('sheet');
  const sIn = eo5(seg(t, ...T.sheetIn));
  sheet.style.opacity = t >= T.sheetIn[0] && t < T.endCut ? 1 : 0;
  sheet.style.transform = `translate(${(1 - sIn) * 1000}px, ${(1 - sIn) * 60}px) rotate(${lerp(-3.2, -1.2, sIn)}deg)`;
  stampStyle($('sheetStamp'), t, T.sheetStamp, tiltOf('assaut mené'));

  // Le carton final.
  const end = $('end');
  end.style.opacity = t >= T.endCut ? 1 : 0;
  if (t >= T.endCut) {
    $('er3').style.transform = `scaleX(${eio(seg(t, T.endCut, T.endCut + 0.3))})`;
    $('er1a').style.transform = `scaleX(${eio(seg(t, T.endCut + 0.04, T.endCut + 0.34))})`;
    $('er1b').style.transform = `scaleX(${eio(seg(t, T.endCut + 0.3, T.endCut + 0.6))})`;
    stampStyle(WM2.ww, t, T.endWW, -2);
    WM2.letters.forEach((el, i) => {
      const u = seg(t, T.endSim[i] - 0.06, T.endSim[i] + 0.04);
      el.style.opacity = u > 0 ? 1 : 0;
      el.style.transform = `translateY(${(-0.1 * (1 - eo(u))).toFixed(3)}em)`;
    });
    setWipe($('edl'), eo(seg(t, ...T.endDate)));
    setWipe($('edr'), eo(seg(t, T.endDate[0] + 0.1, T.endDate[1] + 0.1)));
    const ch = eo(seg(t, ...T.endChapo));
    $('chapo').style.opacity = ch; $('chapo').style.transform = `translateY(${(1 - ch) * 12}px)`;
    const b = eo(seg(t, ...T.endBureau));
    $('bureau').style.opacity = b;
    const url = 'wws.pierrebrethes.cloud';
    const n = Math.round(url.length * seg(t, ...T.endUrl));
    $('url').innerHTML = `${url.slice(0, n)}<span style="visibility:hidden">${url.slice(n)}</span>`;
    drawFrieze(t);
  }

  // Grain d'impression : il bouge à chaque image, comme sur une bande projetée.
  const f = Math.round(t * FPS);
  $('grain').style.backgroundPosition = `${(f * 73) % 160}px ${(f * 131) % 160}px`;
  $('vignette').style.opacity = st.vignette;
  $('fade').style.opacity = 1 - eo(seg(t, 0, 0.3));
}

const FRIEZE = ['france', 'uk', 'germany', 'italy', 'ussr', 'china', 'japan', 'usa'];
function drawFrieze(t) {
  const c = $('frieze');
  const g = c.getContext('2d');
  g.clearRect(0, 0, c.width, c.height);
  const slot = c.width / FRIEZE.length;
  FRIEZE.forEach((key, i) => {
    const a = eo(seg(t, T.frieze[0] + i * 0.07, T.frieze[0] + i * 0.07 + 0.25));
    if (a <= 0) return;
    const img = IMG[`${key}/fighter`];
    const ht = halftone(img, 178, 2.3);
    const s = Math.min(1, 124 / ht.h);
    g.globalAlpha = a;
    g.drawImage(ht.canvas, slot * i + (slot - ht.w * s) / 2, 14 + (128 - ht.h * s) / 2, ht.w * s, ht.h * s);
  });
  g.globalAlpha = 1;
}

/* ------------------------------------------------------------- état */

function stateAt(t) {
  const lift = eio(seg(t, ...T.lift));
  const board = eio(seg(t, 6.0, 6.9));
  const st = {
    pageAlpha: 1,
    hatch: 1 - seg(t, 5.8, 6.3),
    pageText: 1 - seg(t, 5.72, 6.05),
    Hb: lift * 1.6 * K,
    T: lift * 0.3 * K,
    halftone: 1 - seg(t, 5.85, 6.45),
    graticule: lerp(0.16, 0.11, board),
    wash: board,
    isobaths: [lerp(0.3, 0.44, board), lerp(0.0, 0.32, board), lerp(0.24, 0.24, board), lerp(0.0, 0.17, board)],
    isoWidth: lerp(0.9, 1.4, board),
    borderWidth: lerp(0.8, 1.5, board),
    rimWidth: lerp(2.2, 3.2, board),
    seaPass: seg(t, ...T.seaPass),
    landPass: seg(t, ...T.landPass),
    seaOff: [-8 * (1 - eo(seg(t, T.seaPass[0], T.seaPass[1] + 0.35))), 4 * (1 - eo(seg(t, T.seaPass[0], T.seaPass[1] + 0.35)))],
    landOff: [9 * (1 - eo(seg(t, T.landPass[0], T.landPass[1] + 0.3))), -5 * (1 - eo(seg(t, T.landPass[0], T.landPass[1] + 0.3)))],
    inks: NATIONS.map((n, i) => seg(t, T.inkStart + i * T.inkStep, T.inkStart + i * T.inkStep + T.inkDur)),
    vignette: t < T.zoom[0] ? 0.55 : t < T.endCut ? lerp(0.55, 0.95, seg(t, ...T.zoom)) : 0.42,
    masts: {},
    enemyHead: null,
  };
  return st;
}

/* ----------------------------------------------------------- rendu */

function renderAt(t) {
  t = clamp(t, 0, DURATION);
  setCamera(cameraAt(t));
  const st = stateAt(t);
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  ctx.fillStyle = C.desk; ctx.fillRect(0, 0, W, H);

  if (t < T.endCut) {
    drawPage(ctx, st);
    const printing = t < T.landPass[1];
    if (printing) {
      gA.setTransform(1, 0, 0, 1, 0, 0); gA.clearRect(0, 0, W, H);
      if (st.seaPass > 0) drawSea(gA, st);
      printPass(layerA, st.seaPass, st.seaOff);
      gB.setTransform(1, 0, 0, 1, 0, 0); gB.clearRect(0, 0, W, H);
      if (st.landPass > 0) { drawLand(gB, st); drawBorders(gB, st); }
      printPass(layerB, st.landPass, st.landOff);
    } else {
      drawSea(ctx, st);
      drawLand(ctx, st);
    }
    if (!printing) {
      drawInks(ctx, st);
      drawBorders(ctx, st);
    } else if (st.inks.some((u) => u > 0)) drawInks(ctx, st);

    // Légendes : filet de rappel et point de capitale.
    const la = 1 - seg(t, ...T.labelsOut);
    if (la > 0) {
      NATIONS.forEach((n, i) => {
        const a = clamp((st.inks[i] - 0.15) * 2.5) * la;
        if (a <= 0) return;
        const z = st.Hb + st.T;
        const [cx, cy] = proj(PT[n.cap][0], PT[n.cap][1], z);
        ctx.save(); ctx.globalAlpha = a;
        if (n.side !== 'center') {
          const [lx, ly] = proj(PT[n.lbl][0], PT[n.lbl][1], z);
          const u = eo(clamp((st.inks[i] - 0.15) * 3));
          ctx.strokeStyle = C.ink; ctx.lineWidth = 1.2;
          ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(lerp(cx, lx, u), lerp(cy, ly, u)); ctx.stroke();
        }
        ctx.fillStyle = C.paper; ctx.strokeStyle = C.ink; ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.arc(cx, cy, 4.5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.fillStyle = C.ink; ctx.beginPath(); ctx.arc(cx, cy, 1.8, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      });
    }

    // Le plateau.
    if (t >= T.masts[0]) drawBoard(t, st);
  }
  updateDom(t, st);
}

function drawBoard(t, st) {
  const z = st.Hb + st.T + 0.05;
  const sprite = (key, w, pitch, p, anchor, a, scale) => drawSprite(IMG[key], w, pitch, p[0], p[1], anchor, a, scale);

  drawRing(z, seg(t, ...T.ring));

  // Fils : le tracé complet se déroule, puis le pion avance à vitesse constante.
  const routes = [
    ['land', T.land, 'france/armor-2', 168, 2.5, 'foot'],
    ['sea', T.sea, 'france/escort', 210, 2.5, 'foot'],
    ['air', T.air, 'france/fighter', 160, 2.5, 'center'],
  ];
  const pawns = [];
  for (const [key, [t0, t1], img, w, pitch, anchor] of routes) {
    const route = ROUTES[key];
    route.air = key === 'air';
    const shown = eio(seg(t, t0 - 0.05, t0 + 0.4));
    // Terre et air arrivent ; le bâtiment de mer est encore en route quand le film s'arrête.
    const done = key === 'sea' ? clamp((t - t0 - 0.25) / (t1 - t0)) * 0.75 : clamp((t - t0 - 0.25) / (t1 - t0 - 0.25));
    // Un mouvement arrivé n'a plus de fil : la troupe est posée, seule la planche reste.
    const gone = key === 'sea' ? 0 : seg(t, t1 + (key === 'land' ? 0.35 : 0.05), t1 + (key === 'land' ? 0.75 : 0.4));
    if (gone < 1) { ctx.save(); ctx.globalAlpha = 1 - gone; drawThread(route, shown, Math.max(0, done), z, key); ctx.restore(); }
    if (shown > 0.3) {
      const p = routeAt(route, Math.max(0, done));
      const [sx, sy] = proj(p.x, p.y, z + p.h);
      pawns.push({ y: sy, draw: () => sprite(img, w, pitch, [sx, sy], anchor, eo(seg(t, t0 + 0.15, t0 + 0.4)), lerp(0.75, 1, eo(seg(t, t0 + 0.15, t0 + 0.45)))) });
    }
  }

  const enemyHead = drawEnemy(t, z);
  if (enemyHead) st.enemyHead = enemyHead;

  // Mâts, du fond vers l'avant.
  for (const site of SITES) {
    const m = drawMast(PT[site.key], z, seg(t, site.at(), site.at() + 0.22), INK.france);
    if (m) st.masts[site.key] = m;
  }
  pawns.sort((a, b) => a.y - b.y).forEach((p) => p.draw());
  drawBurst(t, z);
}

/* --------------------------------------------------------- démarrage */

window.ready = load().then(() => {
  KEYS = cameraKeys();
  const q = new URLSearchParams(location.search);
  if (q.has('t')) { renderAt(parseFloat(q.get('t'))); return; }
  if (q.has('still')) return;
  // Ouvert à la main : le film se joue en boucle.
  const start = performance.now();
  const loop = (now) => { renderAt(((now - start) / 1000) % (DURATION + 1)); requestAnimationFrame(loop); };
  requestAnimationFrame(loop);
});
window.renderAt = renderAt;
window.TIMELINE = T;
