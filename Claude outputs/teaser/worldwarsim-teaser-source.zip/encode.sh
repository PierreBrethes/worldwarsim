#!/usr/bin/env bash
# Deux sorties : la copie maîtresse (CRF 16) et une version légère (< 8 Mo) pour les messageries.
set -euo pipefail
cd "$(dirname "$0")"
ffmpeg -y -loglevel error -framerate 25 -i frames/f%05d.png -i audio/sfx.wav \
  -c:v libx264 -preset slow -crf 16 -pix_fmt yuv420p -profile:v high -tune animation \
  -c:a aac -b:a 192k -movflags +faststart -shortest -metadata title="WorldWarSim" out/worldwarsim-teaser-16x9.mp4
cd out
ffmpeg -y -loglevel error -framerate 25 -i ../frames/f%05d.png -c:v libx264 -preset slow -b:v 3900k \
  -pix_fmt yuv420p -profile:v high -tune animation -pass 1 -an -f null /dev/null
ffmpeg -y -loglevel error -framerate 25 -i ../frames/f%05d.png -i ../audio/sfx.wav -c:v libx264 -preset slow -b:v 3900k \
  -pix_fmt yuv420p -profile:v high -tune animation -pass 2 -c:a aac -b:a 160k -movflags +faststart -shortest \
  -metadata title="WorldWarSim" worldwarsim-teaser-16x9-leger.mp4
rm -f ffmpeg2pass-0.log*
cd ..
cp "$(ls frames/f*.png | tail -1)" out/worldwarsim-teaser-affiche.png
echo FINI
