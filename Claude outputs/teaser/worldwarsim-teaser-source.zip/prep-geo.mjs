// Projette tout ce qui a une longitude avec la projection exacte du jeu
// (scripts/generate-world.mjs : geoNaturalEarth1().fitExtent([[0,0],[400,208]], Sphere)).
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { geoNaturalEarth1 } from 'd3-geo';

// Le monde du jeu : public/world.json du dépôt (ce dossier vit dans « Claude outputs/teaser »).
const WORLD = [process.argv[2], '../../public/world.json', '/mnt/user-data/uploads/Worldwarsim/public/world.json']
  .find((path) => path && existsSync(path));
const world = JSON.parse(readFileSync(WORLD, 'utf8'));
const projection = geoNaturalEarth1().fitExtent([[0, 0], [400, 208]], { type: 'Sphere' });
const r2 = (v) => Math.round(v * 1000) / 1000;
const P = (lon, lat) => projection([lon, lat]).map(r2);

// Contrôle : le point représentatif de la France doit retomber sur son `c`.
const fr = world.countries.find((c) => c.a === 'FRA');
const back = P(fr.ll[0], fr.ll[1]);
console.log('contrôle France', fr.c, back);

const cities = {
  paris: [2.35, 48.86], london: [-0.13, 51.51], washington: [-77.04, 38.91],
  moscow: [37.62, 55.75], berlin: [13.4, 52.52], tokyo: [139.69, 35.69],
  rome: [12.5, 41.9], beijing: [116.4, 39.9],
  dijon: [5.04, 47.32], toulon: [5.93, 43.12], algiers: [3.06, 36.75],
  turin: [7.69, 45.07], milan: [9.19, 45.46], metz: [6.18, 49.12], nancy: [6.18, 48.69],
  saarbrucken: [6.99, 49.24], strasbourg: [7.75, 48.58], kaiserslautern: [7.77, 49.44],
  brest: [-4.49, 48.39], marseille: [5.37, 43.3], lyon: [4.84, 45.76],
  meet: [6.8, 49.15], mannheim: [8.47, 49.49],
  // ancres des légendes de la planche (en mer, ou au cœur des grands pays)
  lblUk: [-30, 57], lblFrance: [-25, 45], lblGermany: [3, 65.5], lblItaly: [17.5, 35.2],
  lblUssr: [80, 63], lblUsa: [-100, 40.5], lblChina: [103, 33.5], lblJapan: [153, 31],
  // cadrages du plateau
  camP3: [5.4, 46.4], camP3b: [6.2, 48.85],
};
const projected = Object.fromEntries(Object.entries(cities).map(([k, [lon, lat]]) => [k, P(lon, lat)]));

const graticule = [];
for (let lon = -180; lon <= 180; lon += 15) {
  const line = [];
  for (let lat = -90; lat <= 90; lat += 1) line.push(P(lon, lat));
  graticule.push(line);
}
for (let lat = -75; lat <= 75; lat += 15) {
  const line = [];
  for (let lon = -180; lon <= 180; lon += 1) line.push(P(lon, lat));
  graticule.push(line);
}

// 1° de latitude en unités de carte, au voisinage de la France : l'échelle des kilomètres.
const [, y45] = P(5, 45); const [, y46] = P(5, 46);
console.log('unités par degré de latitude vers 45°N', r2(y45 - y46));

writeFileSync('data/geo.json', JSON.stringify({
  outline: world.meta.outline,
  countries: world.countries.map((c) => ({ n: c.n, a: c.a, c: c.c, p: c.p })),
  cities: projected,
  graticule,
}));
console.log('ok', Object.keys(projected).length, 'villes,', graticule.length, 'lignes de canevas');
