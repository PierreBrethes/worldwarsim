#!/usr/bin/env bash
# Images → bande son → MP4. À lancer depuis ce dossier.
set -euo pipefail
cd "$(dirname "$0")"

python3 -m http.server 8123 --bind 127.0.0.1 >/dev/null 2>&1 &
SERVER=$!
trap 'kill $SERVER' EXIT
sleep 1

rm -rf frames && mkdir -p frames out audio
node render.mjs --frames            # écrit aussi data/timeline.json
python3 sfx.py
./encode.sh
