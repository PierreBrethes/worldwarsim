// Banc de rendu : une image par 1/25 s, sans horloge.
//   node render.mjs --stills 0.5,2.6,7.4     → out/still-<t>.png
//   node render.mjs --frames [--from 0 --to 15] → frames/f00000.png …
let chromium;
try {
  ({ chromium } = await import('playwright'));
} catch {
  ({ chromium } = await import('/opt/npm-tools/node_modules/playwright/index.mjs'));
}
import { mkdirSync, writeFileSync } from 'node:fs';

const args = process.argv.slice(2);
const opt = (name, fallback) => {
  const i = args.indexOf(name);
  return i >= 0 ? args[i + 1] : fallback;
};
const FPS = 25;
const URL = opt('--url', 'http://127.0.0.1:8123/teaser.html?still');

const browser = await chromium.launch({
  args: ['--force-color-profile=srgb', '--font-render-hinting=none', '--disable-lcd-text', '--hide-scrollbars'],
});
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') console.log('[page]', m.type(), m.text()); });
page.on('pageerror', (e) => console.log('[page error]', e.message));
await page.goto(URL, { waitUntil: 'load' });
await page.evaluate(() => window.ready);
writeFileSync('data/timeline.json', JSON.stringify(await page.evaluate(() => window.TIMELINE), null, 1));

const shoot = async (t, path) => {
  await page.evaluate((time) => window.renderAt(time), t);
  await page.screenshot({ path, type: 'png' });
};

if (args.includes('--stills')) {
  mkdirSync('out', { recursive: true });
  for (const t of opt('--stills', '0').split(',').map(Number)) {
    const started = Date.now();
    await shoot(t, `out/still-${t.toFixed(2)}.png`);
    console.log('still', t, `${Date.now() - started} ms`);
  }
}

if (args.includes('--frames')) {
  mkdirSync('frames', { recursive: true });
  const from = Math.round(Number(opt('--from', 0)) * FPS);
  const to = Math.round(Number(opt('--to', 15)) * FPS);
  const started = Date.now();
  for (let f = from; f < to; f++) {
    await shoot(f / FPS, `frames/f${String(f).padStart(5, '0')}.png`);
    if (f % 25 === 0) console.log('image', f, `${((Date.now() - started) / (f - from + 1)).toFixed(0)} ms/image`);
  }
}

await browser.close();
